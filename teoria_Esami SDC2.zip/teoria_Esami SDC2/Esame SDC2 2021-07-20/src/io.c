#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>

#include "common.h"
#include "io.h"

int send_to_socket(int sd, const char *msg) {

    /**
     * COMPLETARE QUI
     *
     * Obiettivi:
     * - usare il descrittore sd per inviare tutti i byte della stringa msg
     *   (incluso il terminatore di stringa \0)
     * - come valore di ritorno, restituire il numero di byte inviati (incluso
     *   il terminatore di stringa \0)
     * - gestire eventuali interruzioni, riprendendo l'invio da dove era stato
     *   interrotto
     * - gestire eventuali errori, terminando l'applicazione
     *
     */


    /***/

    int byte_send = 0;
    int ret = 0;

    while (byte_send < strlen(msg)+1){
        ret = send(sd, msg+byte_send, strlen(msg)+1-byte_send, 0);
        if(ret == -1)handle_error("SEND !");
        byte_send += ret;
    }

    return byte_send; /*return inserito per permettere la compilazione. Rimuovere*/

}

int recv_from_socket(int sd, char *msg, int max_len) {

    /**
     * COMPLETARE QUI
     *
     * Obiettivi:
     * - usare il descrittore sd per ricevere una stringa da salvare nel buffer
     *   msg (incluso il terminatore di stringa \0); la lunghezza della stringa
     *   non è nota a priori, ma comunque minore di max_len;
     * - ricevere fino ad un massimo di max_len bytes (incluso il terminatore di
     *   stringa \0);
     * - come valore di ritorno, restituire il numero di byte ricevuti (escluso
     *   il terminatore di stringa \0)
     * - in caso di chiusura inaspettata della socket, restituire 0
     * - gestire eventuali interruzioni, riprendendo la ricezione da dove era
     *   stata interrotta
     * - gestire eventuali errori, terminando l'applicazione
     *
     */


    /***/
    int byte_receive = 0;
    int ret = 0;

    while (msg[(byte_receive-1<0)?0:byte_receive-1]!= '\0'){
        ret = recv (sd, msg+byte_receive, max_len-byte_receive, 0);
        if (ret == 0) return 0;
        if (ret == -1)handle_error ("RECEIVE");
        byte_receive += ret;
    }

    return byte_receive -1; /*return inserito per permettere la compilazione. Rimuovere*/
}
