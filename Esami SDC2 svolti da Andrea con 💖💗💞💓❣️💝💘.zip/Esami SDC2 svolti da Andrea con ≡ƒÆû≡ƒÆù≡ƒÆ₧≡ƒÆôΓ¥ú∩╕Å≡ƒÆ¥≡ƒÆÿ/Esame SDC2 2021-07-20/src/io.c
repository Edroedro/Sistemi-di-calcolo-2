#include <sys/types.h>
#include <sys/socket.h>
#include <string.h>

#include "common.h"
#include "io.h"

int send_to_socket(int sd, const char *msg) {

    /**
     * COMPLETARE QUI
     *
     * Obiettivi:
     * - usare il descrittore sd per inviare tutti i byte della stringa msg
     *   (incluso il terminatore di stringa \0)
     * - come valore di ritorno, restituire il numero di byte inviati (incluso
     *   il terminatore di stringa \0)
     * - gestire eventuali interruzioni, riprendendo l'invio da dove era stato
     *   interrotto
     * - gestire eventuali errori, terminando l'applicazione
     *
     */

	int ret, bytessent = 0;
	while( bytessent < strlen(msg)+1 ) {
		ret = send(sd, msg + bytessent, strlen(msg)+1-bytessent, 0);
		if (ret == -1) handle_error("send");
		bytessent += ret;
	}

    /***/
    return bytessent;

}

int recv_from_socket(int sd, char *msg, int max_len) {

    /**
     * COMPLETARE QUI
     *
     * Obiettivi:
     * - usare il descrittore sd per ricevere una stringa da salvare nel buffer
     *   msg (incluso il terminatore di stringa \0); la lunghezza della stringa
     *   non è nota a priori, ma comunque minore di max_len;
     * - ricevere fino ad un massimo di max_len bytes (incluso il terminatore di
     *   stringa \0);
     * - come valore di ritorno, restituire il numero di byte ricevuti (escluso
     *   il terminatore di stringa \0)
     * - in caso di chiusura inaspettata della socket, restituire 0
     * - gestire eventuali interruzioni, riprendendo la ricezione da dove era
     *   stata interrotta
     * - gestire eventuali errori, terminando l'applicazione
     *
     */

	int ret, bytesrecieved = 0;

	while(bytesrecieved < strlen(msg)+1) {
		ret = recv(sd, msg + bytesrecieved, strlen(msg)+1-bytesrecieved, 0);
		if (ret == -1) handle_error("recv");
		if (ret == 0) return 0;
		bytesrecieved += ret;
	}

    /***/
    return bytesrecieved-1;
}
