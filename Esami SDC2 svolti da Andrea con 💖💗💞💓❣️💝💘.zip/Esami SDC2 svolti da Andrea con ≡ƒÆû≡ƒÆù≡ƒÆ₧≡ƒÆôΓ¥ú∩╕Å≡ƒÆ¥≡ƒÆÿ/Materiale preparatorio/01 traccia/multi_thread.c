#include <pthread.h>
#include <semaphore.h>
#include "common.h"

#define BUFFER_LENGTH 5
#define THREAD_COUNT 4
#define ITERATION_COUNT 10
#define PROD_ROLE 0
#define CONS_ROLE 1

typedef struct thread_args_s {
    int idx;
    int role;
} thread_args_t;

int buffer[BUFFER_LENGTH];
int write_index, read_index;

/**
 * COMPLETARE QUI
 *
 * Obiettivi:
 * - dichiarare i semafori necessari
 *
 */

sem_t cellepiene;
sem_t cellevuote;
sem_t accedendo;

/***/

void producer_routine(int idx) {

    /**
     * COMPLETARE QUI
     *
     * Obiettivi:
     * - completare l'implementazione secondo il paradigma
     *   multi-prod/multi-cons inserendo operazioni sui
     *   semafori ove necessario
     * - gestire gli errori
     *
     */
	
     int i, ret;
     for (i = 0; i < ITERATION_COUNT; i++) {
        int value = idx*ITERATION_COUNT + i;

		ret = sem_wait(&cellevuote);
		if(ret) handle_error("wait vuote");
		ret = sem_wait(&accedendo);
		if(ret) handle_error("wait accedendo");
		
        buffer[write_index] = value;
        write_index = (write_index + 1) % BUFFER_LENGTH;

		ret = sem_post(&accedendo);
		if(ret) handle_error("post accedendo");
		ret = sem_post(&cellepiene);
		if(ret) handle_error("post piene");

        printf("[Thread #%d] inserito %d nel buffer\n", idx, value);
     }
}

void consumer_routine(int idx) {

    /**
     * COMPLETARE QUI
     *
     * Obiettivi:
     * - completare l'implementazione secondo il paradigma
     *   multi-prod/multi-cons inserendo operazioni sui
     *   semafori ove necessario
     * - gestire gli errori
     *
     */




     int i, ret;
     for (i = 0; i < ITERATION_COUNT; i++) {

		ret = sem_wait(&cellepiene);
		if(ret) handle_error("wait piene");
		ret = sem_wait(&accedendo);
		if(ret) handle_error("wait accedendo");

        int value = buffer[read_index];
        read_index = (read_index + 1) % BUFFER_LENGTH;

		ret = sem_post(&accedendo);
		if(ret) handle_error("post accedendo");
		ret = sem_post(&cellevuote);
		if(ret) handle_error("post vuote");

        printf("[Thread #%d] letto %d dal buffer\n", idx, value);
     }
}


void *thread_routine(void *args) {

    thread_args_t *thread_args = (thread_args_t*)args;
    if (thread_args->role == PROD_ROLE) {
        producer_routine(thread_args->idx);
    } else if (thread_args->role == CONS_ROLE) {
        consumer_routine(thread_args->idx);
    } else {
        printf("[Thread #%d] ruolo sconosciuto: %d\n", thread_args->idx, thread_args->role);
    }

    pthread_exit(NULL);
}

int main(int argc, char* argv[]) {

    int ret;

    // inizializzazioni
    read_index = write_index = 0;

    /**
     * COMPLETARE QUI
     *
     * Obiettivi
     * - inizializzare i semafori dichiarati
     * - gestire gli errori
     */

	ret = sem_init(&cellevuote, 0, BUFFER_LENGTH);
	if (ret) handle_error("init");
	ret = sem_init(&cellepiene, 0, 0);
	if (ret) handle_error("init");
	ret = sem_init(&accedendo, 0, 1);
	if (ret) handle_error("init");

    /***/

    /**
     * COMPLETARE QUI
     *
     * Obiettivi: creazione thread
     * - ogni thread deve invocare la funzione thread_routine()
     * - gli argomenti per il thread devono essere specificati
     *   all'interno di una struttura thread_args_t
     * - il campo role può assumere come valori PROD_ROLE o CONS_ROLE
     * - ogni thread ha un valore di idx diverso tra 0 e THREAD_COUNT-1
     * - ci dovranno essere THREAD_COUNT/2 thread con ruolo produttore
     *   ed altrettanti con ruolo consumatore (THREAD_COUNT è pari)
     * - gestire glie errori
     * - N.B.: si tenga presente che successivamente il programma
     *   dovrà attendere la terminazione di ogni thread
     * 
     */
	
	pthread_t thread[THREAD_COUNT];
	thread_args_t * argomenti;
	for (int idx = 0; idx < THREAD_COUNT; idx++) {
		argomenti = malloc(sizeof(thread_args_t));
		argomenti->idx = idx;
		if (idx%2) argomenti->role = PROD_ROLE;
		else argomenti->role = CONS_ROLE;
		ret = pthread_create(thread + idx, NULL, thread_routine, argomenti);
		if (ret) handle_error("pthread create");
	}

    /***/

    /**
     * COMPLETARE QUI
     *
     * Obiettivi:
     * - attendere la terminazione dei thread lanciati in precedenza
     * - gestire gli errori
     */

	for (int i = 0; i<THREAD_COUNT; i++) {
		ret = pthread_join(thread[i], NULL);
		if (ret) handle_error("pthread_join");
	}

    /***/

    /**
     * COMPLETARE QUI
     *
     * Obiettivi:
     * - rilasciare i semafori inizializzati in precedenza
     * - gestire gli errori
     */

	ret = sem_destroy(&cellevuote);
	if (ret) handle_error("destroy");
	ret = sem_destroy(&cellepiene);
	if (ret) handle_error("destroy");
	ret = sem_destroy(&accedendo);
	if (ret) handle_error("destroy");
    /***/

    printf("[Main Thread] operazioni completate\n");

    return EXIT_SUCCESS;
}
